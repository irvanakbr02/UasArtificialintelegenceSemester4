<?php
require_once 'bayes.php';
 ?>
